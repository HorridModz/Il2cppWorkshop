﻿namespace Il2CppDumper
{
    public class DataSection
    {
        public uint Index;
        public uint Offset;
        public byte[] Data;
    }
}
