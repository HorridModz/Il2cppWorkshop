#All plugins must be named the exact same as the file name in their respective config.json file
#They must also have this boilerplate at the top

def onlaunch():
    #Thanks to https://stackoverflow.com/questions/11990556/how-to-make-global-imports-from-a-function for global import!
    class GlobalImport:
            
            def __enter__(self):
                return self
        
            def __call__(self):
                import inspect
                self.collector = inspect.getargvalues(inspect.getouterframes(inspect.currentframe())[1].frame).locals

            def __exit__(self, *args):
                globals().update(self.collector)
    def getdirectories():
        import os
        import sys
        try:
            global plugindirectory
            plugindirectory = os.getcwd()
            global rootdirectory
            rootdirectory = plugindirectory[0:plugindirectory.find(r"Il2cppWorkshop\Plugins") + len(r"Il2cppWorkshop")]
            sys.path.append(plugindirectory)
            sys.path.append(plugindirectory + r"\Resources\Modules\Python")
            sys.path.append(plugindirectory + r"\Resources\Required Modules\Python")
        except:
            raise OSError("Could not find Il2cppWorkshop root direcotoy.\
     Is this plugin in Il2cppWorkshop's Plugins folder?")
    def loadil2cppworkshopandplugindata():
        try:
            #Load respective PluginData.json file for this plugin
            plugindatapath = plugindirectory + r"\PluginData.json"
            with open(plugindatapath,'r') as f:
                content = f.read()
        except Exception as exception:
            raise Exception("Failed to load PluginData.json file: " + exception + ". Is this file in this plugin's directory?")
        try:
            import json
        except:
            raise ModuleNotFoundError("Failed to import module 'json': Module not found.")
        try:
            global plugindata
            plugindata = json.loads(content)
        except:
            raise SyntaxError("Failed to parse PluginData.json: invalid syntax for json file.")
        try:
            #Get language from PluginData.json
            language = str(plugindata["Language"]).lower()
        except:
            raise Exception("Could not find 'Language' key in PluginData.json.")
        #Import correct Il2cppWorkshop script for language
        #Of course plugin boilerplate is different for each language
        #This means that this python boilerplate will only support python plugins
        if language == "python" or language == "py" or language == "python3" or language == "py3":
            try:
                with GlobalImport() as toglobal:
                    import Il2cppWorkshopCore as Il2cppWorkshop
                    toglobal()
            except:
                raise OSError("Could not find 'Il2cppWorkshopCore.py'.\
     Is this script in the plugin's Il2cppWorkshop folder?")
        else:
            raise Exception(f"Plugin language ({language}) in PluginData.json contradicts language plugin is actually coded in (python).")
    def importmodules():
        try:
            #Get required modules from PluginData.json
            requiredmodules = plugindata["RequiredModules"]
        except:
            raise Exception("Could not find 'RequiredModules' key in PluginData.json.")
        #Import required modules
        for module in requiredmodules:
            Il2cppWorkshop.importmodule(module)
    getdirectories()
    loadil2cppworkshopandplugindata()
    importmodules()
    Il2cppWorksop.init()

onlaunch()
