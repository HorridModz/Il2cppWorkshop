﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Il2CppDumper
{
    public class BlobValue
    {
        public object Value;
        public Il2CppTypeEnum il2CppTypeEnum;
        public Il2CppType EnumType;
    }
}
