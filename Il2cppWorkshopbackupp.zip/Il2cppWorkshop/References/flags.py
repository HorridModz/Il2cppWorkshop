class initflags():
  def __init__(self):
    self.flags = {"A": False,"B": False}
  def update(self,flagname,status = True):
    self.flags[flagname] = status
  def toggle(self,flagname):
    self.flags[flagname] = (not(self.flags[flagname]))
  def get(self,flagname):
    return(self.flags[flagname])
    
 
global flags
flags = initflags()
print(flags.get("A"))
flags.update("A",True)
print(flags.get("A"))
flags.toggle("A")
print(flags.get("A"))
 
