# AUDeobfuscator
A simple script to help with the deobfuscation of il2cpp files

You can use https://github.com/djkaty/Il2CppInspector to decompile the among us DLL

Then put the il2cpp-types.h and the il2cpp-types-ptr.h in the data/clean folder and run `./deobfuscate.sh` only works on mac or linux
