Bools:

1: Stun
3: Armor Regen
4-5: No Damage
6-end: Ammo

Look out for:
Damage Increase
Slowdown
Double Jump (Ninja Jump)
Increased AOE
Increased Grenade AOE
Stealth (silent)
Health Regen
Armor Regen
No Ammo Used When Firing (turbo charger)
Recover Bullet Chance (magic bullet)
Stun (disable jump)
No Damage
Piercing Shells (primary weapon damage increase)
No Dispersion (steel hands) (less spread)
Critical Hits (fortune)
Xray (may need sniper with oracle module equipped to get xray, untested) (oracle)
Recover health on critical hit
Speed after kill
Explosion on death (death damage) (last word)
Grenade on reload
No Recoil
Lifesteal (vampire)

Floats:
1-end: Damage